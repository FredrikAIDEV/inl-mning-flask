from flask import Flask, redirect, url_for, render_template

posts = [
    {
        'author' : 'Namn Efternamn',
        'title': 'Blog post 1',
        'content': 'Här kommer ett inlägg för att testa min blog.',
        'date_posted': '2023-03-20'
    },
    {
        'author' : 'Namn Efternamn',
        'title': 'Blog post 2',
        'content': 'Här kommer ett inlägg till! vilken bra sida!',
        'date_posted': '2023-03-21'
    }

]

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html", content = "test")
@app.route("/mig")
def ommig():
    return render_template("mig.html", content = "mig")

@app.route("/kontakt")
def kontakt():
    return render_template("kontakt.html", content = "kontakt")

@app.route("/cv")
def cv():
    return render_template("cv.html", content = "cv")

@app.route("/index")
def index():
    return render_template("index.html", content = "index")

@app.route('/blog')
def blog():
    return render_template('blog.html', content = 'blog', posts = posts, title = 'Flask blog')

if __name__ =="__main__":
    app.run()



